var count=1;
var k=0;
var sequence=[];
var ansequence=[];
function randomisation(count)
{
    var arr=[1,2,3,4];
    var prob=[];
    for(var i=0;i<4;i++)
    {
        prob[i]=Math.floor((Math.random()*6))+1;
    };

    for(var i=0;i<=2;i++)
    {
        var min1=prob[i];
        var min2=arr[i];
        for(var j=i+1;j<=3;j++)
        {
            if(min1>prob[j])
            {
                min2=min2+arr[j];
                arr[j]=min2-arr[j];
                min2=min2-arr[j];
            }
        }
        arr[i]=min2;
    }

    var repeat=[];
    for(var i=0;i<=3;i++)
    {
        repeat[i]=Math.floor(Math.random()*2)+1;
    }

    
    var l=0;
    for(var i=0;i<4;i++)
    {
        for(var j=0;j<repeat[i];j++)
        {
            sequence[l++]=arr[i];
        }
    }
            console.log(arr);
            console.log(repeat);
            console.log(sequence);
            //console.log(ansequence);
}

Question(count);

function Question(count)
{
    if(count==1)
    randomisation(count);
    else if(count>5)
    {
        return;
    }
    else
    {
        var len=sequence.length;
        sequence[len]=Math.floor(Math.random()*4)+1;
        len=sequence.length;
        sequence[len]=Math.floor(Math.random()*4)+1;
    }

    document.querySelectorAll(".btn")[0].addEventListener("click",function fun()
    {
        document.querySelectorAll("h1")[0].innerHTML="Level "+count;
        document.querySelectorAll(".btn")[0].removeEventListener("click",fun);
        console.log("here");
        
        setTimeout(function()
        {
            for (let i = 0; i <sequence.length; i++) 
            {
                setTimeout(function timer() 
                {
                    if(sequence[i]==1)
                    {
                        var audio=new Audio("sounds/green.mp3");
                        audio.play();
                        document.querySelectorAll(".btn")[0].style.backgroundColor="white";
                        setTimeout(function(){document.querySelectorAll("div.btn")[0].style.backgroundColor="green";},1000);
                        console.log("here1");
                    }
                    else if(sequence[i]==2)
                    {
                        var audio=new Audio("sounds/red.mp3");
                        audio.play();
                        document.querySelectorAll(".btn")[1].style.backgroundColor="white";
                        setTimeout(function(){document.querySelectorAll("div.btn")[1].style.backgroundColor="red";},1000);
                        console.log("here2");
                    }
                    else if(sequence[i]==3)
                    {
                        var audio=new Audio("sounds/yellow.mp3");
                        audio.play();
                        document.querySelectorAll(".btn")[2].style.backgroundColor="white";
                        setTimeout(function(){document.querySelectorAll("div.btn")[2].style.backgroundColor="yellow";},1000);
                        console.log("here3");
                    }
                    else if(sequence[i]==4)
                    {
                        var audio=new Audio("sounds/blue.mp3");
                        audio.play();
                        document.querySelectorAll(".btn")[3].style.backgroundColor="white";
                        setTimeout(function(){document.querySelectorAll("div.btn")[3].style.backgroundColor="blue";},1000);
                        console.log("here4");
                    } 
                }, i * 2000);
            }
        },2000)
        

        setTimeout(function()
        {
            console.log("Now it starts");
            document.querySelectorAll(".btn")[3].addEventListener("click",game3);
            document.querySelectorAll(".btn")[0].addEventListener("click",game);
            document.querySelectorAll(".btn")[1].addEventListener("click",game1);
            document.querySelectorAll(".btn")[2].addEventListener("click",game2);            

        },sequence.length*2000+2000)
        
    });
}

function evaluation()
{
    if(ansequence[k-1]==sequence[k-1])
    {
        
        console.log("here");
        if(ansequence.length==sequence.length)
        {
            count++;
            var audio=new Audio("sounds/celebration.mp3");
            audio.play();
            document.querySelectorAll(".btn")[0].removeEventListener("click",game);
            document.querySelectorAll(".btn")[1].removeEventListener("click",game1);
            document.querySelectorAll(".btn")[2].removeEventListener("click",game2);
            document.querySelectorAll(".btn")[3].removeEventListener("click",game3);
            console.log("here");
            ansequence=[];
            console.log("call");
            k=0;
            
            console.log("Complete");

            if(count!=5)
            {
                Question(count);
                document.querySelector("h1").innerHTML="Press the green key to go to the next level";
            }
            else
            {
                document.querySelectorAll("h1")[0].innerHTML="Congratulations your score is 50";

            }
            return;
        }
    }
    else
    {
        var audio=new Audio("sounds/wrong.mp3");
        audio.play();
        document.querySelectorAll(".btn")[0].removeEventListener("click",game);
        document.querySelectorAll(".btn")[1].removeEventListener("click",game1);
        document.querySelectorAll(".btn")[2].removeEventListener("click",game2);
        document.querySelectorAll(".btn")[3].removeEventListener("click",game3);
        console.log("here");
        document.querySelector("h1").innerHTML="Game Over - Your score is "+(count-1)*10;
        return;
    }
}

function game()
{
    var audio=new Audio("sounds/green.mp3");
    ansequence[k++]=1;
    document.querySelectorAll(".btn")[0].style.backgroundColor="white";
    setTimeout(function(){document.querySelectorAll("div.btn")[0].style.backgroundColor="green";},500);
    console.log(ansequence);
    audio.play();
    evaluation();
    
}

function game1()
{
    var audio=new Audio("sounds/red.mp3");
    ansequence[k++]=2;
    document.querySelectorAll(".btn")[1].style.backgroundColor="white";
    setTimeout(function(){document.querySelectorAll("div.btn")[1].style.backgroundColor="red";},500);
    console.log(ansequence);
    audio.play();
    evaluation();
}

function game2()
{
    var audio=new Audio("sounds/yellow.mp3");
    ansequence[k++]=3;
    document.querySelectorAll(".btn")[2].style.backgroundColor="white";
    setTimeout(function(){document.querySelectorAll("div.btn")[2].style.backgroundColor="yellow";},500);
    console.log(ansequence);
    audio.play();
    evaluation();
    
}

function game3()
{
    var audio=new Audio("sounds/blue.mp3");
    ansequence[k++]=4;
    document.querySelectorAll(".btn")[3].style.backgroundColor="white";
    setTimeout(function(){document.querySelectorAll("div.btn")[3].style.backgroundColor="blue";},500);
    console.log(ansequence);
    audio.play();
    evaluation();
    
}






