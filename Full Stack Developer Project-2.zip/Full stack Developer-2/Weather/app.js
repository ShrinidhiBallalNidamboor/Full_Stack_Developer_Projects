//express is a very common package that heps in getting the various attributs of the functioning of the server setup.
//body-parser, express and the request are the npm libraries.
const express=require("express");
const https=require("https");
const bodyParser = require("body-parser");
var weatherData;
var url;
var app=express();
var city_name;
app.use(bodyParser.urlencoded({ extended: true }));
//This is also an inbuilt function of the node js that gets the response and the request from the client and provides the suitable response in
//in the form of the Chnging the html web page with the variation that can be brought about by the variation in the current page where the get is triggered.
//the / here represents the root route page.
//the /about and others represents the various routes that branch out from the root route.
//The initial part is called the url.

//since this is local server there is no need for the https and other parts of the url.

//the body-parser an important part of the npm library or frame work that hepls in getting the value of the tags inside the form in the body tag.
//post is the method obtained from the body parser.
//this acquires the post message got when the user presses the submit message.

//here the https object method hepls in getting the data through the api and the urls.
app.get("/",function(req,res)
{
    //The response here has the value got by the server after making the api request to the weather server.
    //the initial part is the security code for differntly located Servers.
    //the second part of the url following the question mrk and including the question mark is called the API that returns a Json file formatted text.
    //JSON is a file format.
    //The __dirname gives the path of the current file upto to its parents.
    res.sendFile(__dirname+"/index.html");
});

//post is the method specified in the html form tag.
app.post("/",function(request,res)
{
    city_name=request.body.city_name;
    url="https://api.openweathermap.org/data/2.5/weather?q="+city_name+"&appid=4df24ee1b0cb347aa2343b387e3d9fb8&units=metric";
    console.log(url);
    https.get(url,function(response)
    {
        //console.log(response.statusCode) this prints the state of the execution of the code.
        console.log("Your information is here");
        //The data that is received in the response root is the set of children of the response.
        //Response here is considered as the root of the tree structure of the JSON file that is accessed through the url or the Api.
        //.on method gets the child set of all the children of the response.
        //The https that is used as the object is used in getting the https requests from the server to the server that provides the API's. 
        //if an url is sent as an input to the https get method then the method gets the response that the browser send to it when that particular 
        //url is typed in the text box.
        //The API that is present in the URL are generally going to return a Json file formatted object class file that has already filled objects with values.
        //the response has to be inside the post only.
        response.on("data",function(data)
        {
            //The JSON function that is used is the function that converts the information of all the children of the response root from
            //hexadecimal to text format.
            //JSON. stringify converts the JSON format to the hexadecimal format.
            weatherData=JSON.parse(data);
            //weatherData now becomes the root of the data present inside the response.
            //the is can be accessed by weatherData.child1.child2... and so on.
            res.send("The temperature in "+city_name+" is: "+weatherData.main.temp+" degree celcius");
        });
    });
});

//This represents the evemt listner in the server setup in node js.
//5000 is the common port for all the routes.
app.listen(5000,function()
{
    console.log("The server is running in the port 5000.");
});