//jshint esversion:6
//This is the typical form of the node.js
const express=require("express");
const ejs=require("ejs");
const bodyParser=require("body-parser");
const mongoose=require("mongoose");
const md5=require("md5");
//const encrypt=require("mongoose-encryption");
var username;
const app=express();
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));
app.set('view engine','ejs');
//the app receives the attributes of the express json that has the attributes for performing the operations of api calls.
//bodyparser heps in passing the values from the html to the js file.
//ejs helps in passing the informing from the js to html.


mongoose.connect('mongodb://localhost:27017/registrationsDB');
var personSchema = new mongoose.Schema({
    username: String,
    password: String,
    secrets:[String]
    });
var Person = mongoose.model('Person', personSchema);
// const secret ="Thisisourlittlesecret";
// personSchema.plugin(encrypt, {secret:secret,encryptedFields:["password"]});

//This above code is for keeping secrets.
app.get("/",function(request,response)
{
    response.render("home",{});
});

app.get("/login",function(request,response)
{
    response.render("login",{});
});

app.get("/register",function(request,response)
{
    response.render("register",{});
});

// app.get("/submit1",function(request,response)
// {
//     var username=request.body.user;
//     response.render("submit",{username:username});
// });

app.get("/submit",function(request,response)
{
    response.render("submit",{username:username});
});

app.get("/delete",function(request,response)
{
    Person.updateOne({username:username},{$pop: { secrets: -1}},function(error){if(error){console.log(error);}else{console.log("Sucessfully updated");};});
    Person.find({username:username},function(error,people){
        response.render("secrets",{username:username,secrets:people[0].secrets});
    });
});

app.post("/submit",function(request,response)
{
    var username=request.body.user;
    var secret=request.body.secret;
    Person.updateOne({username:username},{$push: { secrets: secret}},function(error){if(error){console.log(error);}else{console.log("Sucessfully updated");};});
    Person.find({username:username},function(error,people){
        response.render("secrets",{username:username,secrets:people[0].secrets});
    });
    
});
//there are only one send messages.
//this pulls the request from the https request from the user.

app.post("/register",function(request,response)
{
    var username=request.body.username;
    //hashing
    var password=md5(request.body.password);
    console.log("Hello"+request.body.password);
    let person=new Person({username:username,password:password});
    Person.insertMany([person],function(error){if(error){console.log(error);}else{console.log("Sucessfully saved");};});
    response.redirect("/");
});

app.post("/login",function(request,response)
{
    username=request.body.username;
    password=md5(request.body.password);
    console.log("Hello");
    Person.find({username:username},function(error,people){
        if(people)
        {
            if(people[0].password===password)
            {
                console.log("Found it");
                response.render("secrets",{username:username,secrets:people[0].secrets});
            }
            else
            {
                console.log("Not Found it:1");
                response.redirect("/login");
            }
        }
        else
        {
            console.log("Not Found it:2");
            response.redirect("/login");
        };
    });
});

//gets the post requests from the html pages in the form of the form posts or the tree structure.


app.listen(5000, function() {
    console.log("Server started on port 5000");
});

//this function listen to the calls made by the http or https request made from the user.
  