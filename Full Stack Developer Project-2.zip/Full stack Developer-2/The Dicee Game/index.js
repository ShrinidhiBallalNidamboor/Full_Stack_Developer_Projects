var x = document.getElementById("myBtn");
      if (x.addEventListener) 
      {
        x.addEventListener("click", myFunction);
      } 
      else if (x.attachEvent) {
        x.attachEvent("onclick", myFunction);
      }
      
      function myFunction() 
      {
        var element1,element2;
        element1=Math.floor((Math.random())*6)+1;
        element2=Math.floor((Math.random())*6)+1;
        
        if(element1>element2)
        {
        document.querySelector("h1").innerHTML="Player 1 wins this round";
        if(element1==1)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice1.png");
        }
        else if(element1==2)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice2.png");
        }
        else if(element1==3)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice3.png");
        }
        else if(element1==4)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice4.png");
        }
        else if(element1==5)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice5.png");
        }
        else if(element1==6)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice6.png");
        }

        if(element2==1)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice1.png");
        }
        else if(element2==2)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice2.png");
        }
        else if(element2==3)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice3.png");
        }
        else if(element2==4)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice4.png");
        }
        else if(element2==5)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice5.png");
        }
        else if(element2==6)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice6.png");
        }
        }

        else if(element2>element1)
        {
        document.querySelector("h1").innerHTML="Player 2 wins this round";

        if(element1==1)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice1.png");
        }
        else if(element1==2)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice2.png");
        }
        else if(element1==3)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice3.png");
        }
        else if(element1==4)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice4.png");
        }
        else if(element1==5)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice5.png");
        }
        else if(element1==6)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice6.png");
        }

        if(element2==1)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice1.png");
        }
        else if(element2==2)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice2.png");
        }
        else if(element2==3)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice3.png");
        }
        else if(element2==4)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice4.png");
        }
        else if(element2==5)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice5.png");
        }
        else if(element2==6)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice6.png");
        }

        }

        else
        {
          document.querySelector("h1").innerHTML="The Match is Drawn";

          if(element1==1)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice1.png");
        }
        else if(element1==2)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice2.png");
        }
        else if(element1==3)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice3.png");
        }
        else if(element1==4)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice4.png");
        }
        else if(element1==5)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice5.png");
        }
        else if(element1==6)
        {
          document.querySelectorAll("img")[0].setAttribute("src","images/dice6.png");
        }

        if(element2==1)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice1.png");
        }
        else if(element2==2)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice2.png");
        }
        else if(element2==3)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice3.png");
        }
        else if(element2==4)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice4.png");
        }
        else if(element2==5)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice5.png");
        }
        else if(element2==6)
        {
          document.querySelectorAll("img")[1].setAttribute("src","images/dice6.png");
        }
        }
      }