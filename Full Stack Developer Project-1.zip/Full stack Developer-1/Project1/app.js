const express=require("express");
const mongoose=require("mongoose");
const app=express();
const bodyParser=require("body-parser");
var items=[];
var ritems=[];
//ejs stands for Embedded JavaScript Template.
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));
app.set('view engine','ejs');
var type="List";
var today=new Date();
var todayDate=new Date();
var todayMonth=new Date();
var d=today.getDay();
var date=todayDate.getDate();
var month=todayMonth.getMonth();
var m;
var day="";

mongoose.connect('mongodb+srv://atlas-Shrinidhi:Karnataka123@cluster0.z7u2k.mongodb.net/todolistDB');
var todolistSchema = new mongoose.Schema({
    List:String
    });
var ToDoList = mongoose.model('ToDoList', todolistSchema);
items.push("To Read");
items.push("To Cook");
items.push("To Eat");
ToDoList.find({List:"To Read"},function(error,results){
    if(results==null)
    {
        let list=new ToDoList({List:"To Read"});
        ToDoList.insertMany([list],function(error){if(error){console.log(error);}else{console.log("Successfully saved");}});
        
    }
});

ToDoList.find({List:"To Cook"},function(error,results){
    if(results==null)
    {
        let list=new ToDoList({List:"To Cook"});
        ToDoList.insertMany([list],function(error){if(error){console.log(error);}else{console.log("Successfully saved");}});
        
    }
});

ToDoList.find({List:"To Eat"},function(error,results){
    if(results==null)
    {
        let list=new ToDoList({List:"To Eat"});
        ToDoList.insertMany([list],function(error){if(error){console.log(error);}else{console.log("Successfully saved");}});
        
    }
});
ToDoList.find(function(error,list){
    if(error)
    {
        console.log(error);
    }
    else
    {
        //Prints only the names in the array of the objects that is present.
        for(var i=0;i<list.length;i++)
            items.push(list[i].List);
    }
});

app.get("/",function(req,res)
{
    switch(d)
    {
        case 0:
            day="Sunday";
            break;
        case 1:
            day="Monday";
            break;
        case 2:
            day="Tuesday";
            break;
        case 3:
            day="Wednesday";
            break;
        case 4:
            day="Thursday";
            break;
        case 5:
            day="Friday";
            break;
        case 6:
            day="Saturday";
            break;
        default:
            day="wrong";

    }

    switch(month)
    {
        case 0:
            m="January";
            break;
        case 1:
            m="February";
            break;
        case 2:
            m="March";
            break;
        case 3:
            m="April";
            break;
        case 4:
            m="May";
            break;
        case 5:
            m="June";
            break;
        case 6:
            m="July";
            break;
        case 7:
            m="August";
            break;
        case 8:
            m="September";
            break;
        case 9:
            m="October";
            break;
        case 10:
            m="November";
            break;
        case 11:
            m="December";
            break;

    }
    console.log(day);
    type="List";
    res.render("list",{today:day, todayDate:date, todayMonth:m, nitems:items, type:type});
    
});

app.post("/",function(request,response)
{
    if(request.body.list==="work")
    {
        ritems.push(request.body.new);
        response.redirect("/work");
    }
    else if(request.body.list==="List")
    {
        items.push(request.body.new);
        var list=new ToDoList({List:request.body.new});
        ToDoList.insertMany([list],function(error){if(error){console.log(error);}else{console.log("Successfully saved");}});
        response.redirect("/");
    }
    else
    {
        if(request.body.remove_list==="work")
        {
            ritems.pop();
            response.redirect("/work");
        }
        else if(request.body.remove_list==="List")
        {
            ToDoList.deleteOne({List:items[items.length-1]},function(error){if(error){console.log(error);}else{console.log("Successfully deleted");}});
            items.pop();
            response.redirect("/");
        };
    }
});

app.get("/work",function(request,response)
{
    type="work";
    response.render("list",{today:day, todayDate:date, todayMonth:m, nitems:ritems, type:type});
});
let port = process.env.PORT;
if (port == null || port == "") {
  port = 3000;
}

app.listen(port,function()
{
    console.log("The server is running successfully");
});