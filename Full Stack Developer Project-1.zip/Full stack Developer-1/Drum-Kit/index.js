
//The variation of the color based on the this that is the clicked button.
document.querySelectorAll("button")[0].addEventListener("click",function()
{
    var audio=new Audio("sounds/crash.mp3");
    var arr=["blue","red","green"];
    this.style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[0].style.color="#DA0463";
    }, 1000);
    

    audio.play();
});

document.querySelectorAll("button")[1].addEventListener("click",function()
{
    var audio=new Audio("sounds/kick-bass.mp3");
    var arr=["blue","red","green"];
    this.style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[1].style.color="#DA0463";
    }, 1000);
    audio.play();
});

document.querySelectorAll("button")[2].addEventListener("click",function()
{
    var audio=new Audio("sounds/snare.mp3");
    var arr=["blue","red","green"];
    document.querySelectorAll("button")[2].style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[2].style.color="#DA0463";
    }, 1000);
    audio.play();
});

document.querySelectorAll("button")[3].addEventListener("click",function()
{
    var audio=new Audio("sounds/tom-1.mp3");
    var arr=["blue","red","green"];
    this.style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[3].style.color="#DA0463";
    }, 1000);
    audio.play();
});

document.querySelectorAll("button")[4].addEventListener("click",function()
{
    var audio=new Audio("sounds/tom-2.mp3");
    var arr=["blue","red","green"];
    this.style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[4].style.color="#DA0463";
    }, 1000);
    audio.play();
});

document.querySelectorAll("button")[5].addEventListener("click",function()
{
    var audio=new Audio("sounds/tom-3.mp3");
    var arr=["blue","red","green"];
    this.style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[5].style.color="#DA0463";
    }, 1000);
    audio.play();
});

document.querySelectorAll("button")[6].addEventListener("click",function()
{
    var audio=new Audio("sounds/tom-4.mp3");
    var arr=["blue","red","green"];
    this.style.color=arr[Math.floor(Math.random()*3)];
    setTimeout(function(){
       
        document.querySelectorAll("button")[6].style.color="#DA0463";
    }, 1000);
    audio.play();
});

// function student(name, cls, roll, section, ca, num1,num2)
// {
//     this.name=name;
//     this.cls=cls;
//     this.roll=roll;
//     this.section=section;
//     this.ca =function(num1,num2){return num1+num2;};
// }

//Here the event is the parameter that is passed to the function function, here the event gets the value of the event that triggered the event to satisfy the conditions of the listner.
//the settimeout function sets the time of the execution.
document.addEventListener("keydown",function(event)
{ 
    switch(event.key)
    {
        case "w":
            {
                var audio=new Audio("sounds/crash.mp3");
            
                audio.play();
        
                break;
            }
        case "a":
            {
                var audio=new Audio("sounds/kick-bass.mp3");
            
                audio.play();
        
                break;
            }
        case "s":
            {
                var audio=new Audio("sounds/snare.mp3");
                
                audio.play();
        
                break;
            }

        case "d":
            {
                var audio=new Audio("sounds/tom-1.mp3");
                
                audio.play();
        
                break;
            }
        case "j":
            {
                var audio=new Audio("sounds/tom-2.mp3");
            
                audio.play();
        
                break;
            }
        case "k":
            {
                var audio=new Audio("sounds/tom-3.mp3");
            
                audio.play();
        
                break;
            }
        case "l":
            {
                var audio=new Audio("sounds/tom-4.mp3");
        
                audio.play();
        
                break;
            }
    }
});
