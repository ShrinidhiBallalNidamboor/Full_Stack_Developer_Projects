// document.addEventListener("keydown",function(event)
// {
//     document.querySelector("h1").innerHTML=event.key;
// });
//This is the code written for all the js query operations done. 
$(document).keydown(function(event)
{
    $("h1").html(event.key);
});