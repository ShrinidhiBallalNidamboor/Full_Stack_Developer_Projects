//Mongoose usage for the CRUD of the database obtained using the mongodb database.
const mongoose=require("mongoose");
//This requires the mongoose JSON from the package that is installed.
//The most commonly used or the default local host is 27017.
//The personDB is the name of the new database that is created or opened if already present.
//The connect attribute of the mongoose is used to connect to the local host 27017 of the database of the server of the mongoDB.
mongoose.connect('mongodb://localhost:27017/personDB');
//mongoose has the Schema property that gives a new object.
//Also can be used.
//var Person = mongoose.model('Person', new mongoose.Schema({Name: String, age: Number}); );

//Thsi required for the validation of the result that is stored in the individual objects.
//For the required field otherwise a ValidationError.
var personSchema = new mongoose.Schema({
    Name: {type:String, required: true},
    age: {type:Number,max:50,min:1}
    });
var Person = mongoose.model('Person', personSchema);

const person1=new Person({Name:"Shrinidhi",age:19});
const person2=new Person({Name:"Harimurthy",age:47});
const person3=new Person({Name:"Jayashree",age:42});
const person4=new Person({Name:"Shreya",age:13});
//For saving all tge data at once or we could use person1.save().
Person.insertMany([person1,person2,person3,person4],function(error){if(error){console.log(error);}else{console.log("Sucessfully saved");};});
//This step find all the Person data collections from the database of the personDB section and stores it in people.
//Here Person is the collection and it is displayed as the people in the databse collection.
//CRUD operations.
Person.updateOne({Name:"Shrinidhi"},{age:19.5},function(error){if(error){console.log(error);}else{console.log("Sucessfully updated");};});
Person.deleteOne({Name:"Shrinidhi"},function(error){if(error){console.log(error);}else{console.log("Sucessfully deleted");};});
Person.insertMany({person1},function(error){if(error){console.log(error);}else{console.log("Sucessfully saved");};});

var parentSchema = new mongoose.Schema({
    Name: {type:String, required: true},
    age: {type:Number,max:50,min:1},
    son: personSchema
    });

//Thsi sets the link between the two-parents[index].son.Name="Shrinidhi".
var Parent = mongoose.model('Parent', parentSchema);

const parent1=new Parent({Name:"Harimurthy",age:47, son:person1});
const parent2=new Parent({Name:"Jayashree",age:42, son:person1});

parent1.save();
parent2.save();


Person.find(function(error,people){
    if(error)
    {
        console.log(error);
    }
    else
    {
        //Prints only the names in the array of the objects that is present.
        for(var i=0;i<people.length;i++)
            console.log(people[i].Name);
    }
});
//Thsi used for closing the connection with the database.
mongoose.connection.close();