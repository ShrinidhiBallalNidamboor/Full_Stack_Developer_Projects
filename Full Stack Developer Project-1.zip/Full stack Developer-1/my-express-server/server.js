//jshint esersion:6
//Here express in parenthesis is called the library.
const express=require("express");
//This above process is called the initialisation of the obeject express with the object model
//The below given step is called the inheritance of the attributes acquired by the express object after inheritance of the attributes and method.
const app =express();

app.get("/", function(request,response)
{
    response.send("<h1>Hello World</h1>");
});

app.get("/contact", function(request,response)
{
    response.send("<h1>contact at ballalshrinidhi@gmail.com/h1>");
});

app.get("/about", function(request,response)
{
    response.send("<h1>I am currently a student.</h1>");
});

//This is the event listner if the request is sent by the user o the local server.
//localhost:3000 loads the home page, 3000/contact loads the second and so on.

//Port is a channel where the urls can be accepted.
//rout is also the same.
//The home [page is also called the root page.

//The /about / are all the routes the 3000 is the common port.
// if the operations are done on the servers using the node js then they are the web applications and otherwise they are called the web site static applications.
app.listen(3000,function()
{
    console.log("The server started with the port 3000");
});
