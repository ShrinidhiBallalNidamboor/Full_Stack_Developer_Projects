const express=require("express");
const bodyParser=require("body-parser");
const http=require("http");
const app=express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
//The above created page includes all the value and the css and the images used in the html page.

app.get("/",function(request,response)
{
    response.sendFile(__dirname+"/signup.html");
});

app.post("/",function(request,res)
{
    const fname=request.body.fname;
    const lname=request.body.lname;
    const email=request.body.email;

    const url="http://apilayer.net/api/check?access_key=8b1759dfdda09b1afe9c498839315686&email="+email+"&smtp=1&format=1";
    http.get(url,function(response)
    {
        console.log("Your information is here");
        response.on("data",function(data)
        {
            const valid=JSON.parse(data).mx_found;
            if(valid==true)
            {
                res.sendFile(__dirname+"/sucessful.html");
            }

            else
            {
                res.sendFile(__dirname+"/failure.html");
            }
        });
    });
});

app.listen(3000, function()
{
    console.log("The server is running on the port 3000.")
});