// for(var i=0;i<4;i++)
// {
//     document.querySelectorAll(".btn")[i].style.backgroundColor="purple";
// }
// var i=1;
// function myLoop1() {         //  create a loop function
//     setTimeout(function() 
//         {
//             var j=1;
//             function myLoop2() 
//             {         //  create a loop function
//                 setTimeout(function() {   //  call a 3s setTimeout when the loop is called
//                 console.log('hello'+j);   //  your code here
//                 j++;                    //  increment the counter
//                 if (j <=5) 
//                 {           //  if the counter < 10, call the loop function
//                     myLoop2();             //  ..  again which will trigger another 
//                 }                       //  ..  setTimeout()
//                 }, 3000)
//             }
  
//             myLoop2();     //  call a 3s setTimeout when the loop is called
//                 //  your code here
//             i++;                    //  increment the counter
//             if (i <=2) 
//             {           //  if the counter < 10, call the loop function
//                 myLoop1();             //  ..  again which will trigger another 
//             }                       //  ..  setTimeout()
//         }, 3000)
//             }
  
//   myLoop1();  
// sequence=[3,4,1,3,2,2];
// for (let i = 0; i <sequence.length; i++) 
// {
//     setTimeout(function timer() 
//     {
//         console.log(sequence[i]);
//         if(sequence[i]==1)
//                     {
//                         var audio=new Audio("sounds/green.mp3");
//                         audio.play();
//                         document.querySelectorAll(".btn")[0].style.backgroundColor="white";
//                         setTimeout(function(){document.querySelectorAll("div.btn")[0].style.backgroundColor="green";},2000);
//                         console.log("here1");
//                     }
//                     else if(sequence[i]==2)
//                     {
//                         var audio=new Audio("sounds/red.mp3");
//                         audio.play();
//                         document.querySelectorAll(".btn")[1].style.backgroundColor="white";
//                         setTimeout(function(){document.querySelectorAll("div.btn")[1].style.backgroundColor="red";},2000);
//                         console.log("here2");
//                     }
//                     else if(sequence[i]==3)
//                     {
//                         var audio=new Audio("sounds/yellow.mp3");
//                         audio.play();
//                         document.querySelectorAll(".btn")[2].style.backgroundColor="white";
//                         setTimeout(function(){document.querySelectorAll("div.btn")[2].style.backgroundColor="yellow";},2000);
//                         console.log("here3");
//                     }
//                     else if(sequence[i]==4)
//                     {
//                         var audio=new Audio("sounds/blue.mp3");
//                         audio.play();
//                         document.querySelectorAll(".btn")[3].style.backgroundColor="white";
//                         setTimeout(function(){document.querySelectorAll("div.btn")[3].style.backgroundColor="blue";},2000);
//                         console.log("here4");
//                     } 
//     }, i * 3000);
// }

console.log(btn);
let f;
btn.addEventListener('click', f=function(event) 
{
console.log('Click');
console.log(f);
this.removeEventListener('click',f);
console.log('Event removed');
}