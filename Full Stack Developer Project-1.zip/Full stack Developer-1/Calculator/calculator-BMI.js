const bodyParser = require("body-parser");
const express =require("express");
const app=express();

app.use(bodyParser.urlencoded({ extended: true }));

//This takes in all tge request included with the information sent by the user in the form of the form.
//Here the / represents that the post is received from the root route that is the home page.

app.get("/",function(request,response)
{
    response.sendFile(__dirname+"/index.html");
});

app.post("/",function(request, response)
{
    var result=Number(request.body.weight)/((Number(request.body.height))*(Number(request.body.height)));
    response.send("<h1>The BMI Calculator</h1><br>Your BMI is: "+result);
});

app.listen(5000,function()
{
    console.log("The server started with the port 3000");
});